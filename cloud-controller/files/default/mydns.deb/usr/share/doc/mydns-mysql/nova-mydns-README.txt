
"nova-mydns"

OVERVIEW:

MyDNS is a database-driven DNS system which is easy to customize.  This document will
describe how to use it to add a DNS zone with all of your instance hostnames.

This is not really a part of nova at this point, just a prototype of how an auto-dns
system should work.  This document assumes Ubuntu 12.04 and the "Essex" release of OpenStack,
with mysql and nova-network running on localhost.


REQUIREMENTS:
  1) A working nova-network system with the ability to create a couple of tables in the nova db
  2) Enough familiarity with DNS to be able to edit the SQL zone info for your network.


BEFORE GOING ANY FURTHER:

Run backups of at least /etc/nova and your mysql data

# tar czf /root/etc_paranoid.tgz /etc
# mysqldump nova | gzip > /root/mysql_nova_paranoid.sql.gz


STEP 1: disable the DNS part of dnsmasq

I just moved it to a different port in case I needed to use it later, so:

1a: echo "--dnsmasq_config_file=/etc/dnsmasq.conf" >> /etc/nova.conf
1a: echo "port=5353" > /etc/dnsmasq.conf
1b: killall dnsmasq       (required because nova-network doesn't restart dnsmasq if it's running)
1c: restart nova-network


STEP 2: install MyDNS

It looks like Ubuntu doesn't have it in their multiverse, sadly, so I created a package for
Ubuntu 12.04.  While I was at it, I threw in the sample configs that you can use for the next
steps.

2a: dpkg -i http://tpsit.com/packages/mydns-mysql_1.2.8.31_amd64.deb


STEP 3: run SQL script to create MyDNS tables & view

MyDNS uses two tables to hold DNS information instead of a zone file.  In our setup, we will
use the normal dns_addresses table to hold the NS records, and MyDNS will read a view that is
a union between this table and a join between instances and fixed_ips.

In my setup, I added an A record as a landing page for the main OpenStack login; and all of
the VM's are subdomains of this hostname.

3a: copy & modify the sample sql script in /usr/share/doc/mydns... it should be fairly obvious
what to change.
3b: run in mysql with a command like: cat yourmodifiedscript.sql | mysql -p nova
3c: test the DB config, you should see your hosts if you do: SELECT * from dns_addresses_view
3d: Verify that the "zone" column matches the id of your zone in dns_zones;


STEP 4: optional - create a separate mydns user that can only select from dns_*

I just use my novadbadmin login because I'm lazy and this is a test setup


STEP 5: Configure MyDNS

I also put a sample config in the MyDNS package.  All you should need to do from the stock
config file is change the db username/password, change the DB tables it uses, and if you
used dnsmasq for DNS you probably want to enable recursion by setting the DNS server to
forward requests to.

5a: vi /etc/mydns.conf
5b: service mydns start


STEP 6: Test

6a: On your nova-network machine: dig @localhost oneofyourhosts.yourdomain
6b: From a VM, make sure the recursion is working, maybe ping -c1 google.com


Step 7: Enjoy!



