--
--  Table layouts for mydns 1.2.8.31 (May 2012)
--  Copyright (C) 2002-2005 Don Moore  2007-2008 Howard Wilkinson
--
--  This example is for a DNS add-on to nova-network.  If you have any
--  questions, send email to mark@tpsit.com.
--

--
--  This holds the SOA/Zone information
--
--  Refresh is set to a very low value in case we need another name server to
--  slave our zones.  We still need to come up with a way to update the "serial"
--  whenever someone adds a new host, otherwise slave DNS servers won't refresh
--  often enough
--
CREATE TABLE IF NOT EXISTS dns_zones (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  origin     CHAR(255) NOT NULL,
  ns         CHAR(255) NOT NULL,
  mbox       CHAR(255) NOT NULL,
  serial     INT UNSIGNED NOT NULL default '1',
  refresh    INT UNSIGNED NOT NULL default '120',
  retry      INT UNSIGNED NOT NULL default '7200',
  expire     INT UNSIGNED NOT NULL default '604800',
  minimum    INT UNSIGNED NOT NULL default '86400',
  ttl        INT UNSIGNED NOT NULL default '86400',
  UNIQUE KEY (origin)
);

-- In this example, the fixed IP's will be named whatever.openstack.tpsit.com,
-- and floating will be whatever.floating.openstack.tpsit.com.
INSERT INTO dns_zones(id,origin,ns,mbox) VALUES (1,'openstack.tpsit.com.','ns01.tpsit.com.','hostmaster.tpsit.com.');
INSERT INTO dns_zones(id,origin,ns,mbox) VALUES (2,'floating.openstack.tpsit.com.','ns01.tpsit.com.','hostmaster.tpsit.com.');

--
--  Table structure for table 'dns_addresses' (resource records)
--
CREATE TABLE IF NOT EXISTS dns_addresses (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  zone       INT UNSIGNED NOT NULL,
  name       CHAR(200) NOT NULL,
  data       VARBINARY(128) NOT NULL,
  aux        INT UNSIGNED NOT NULL,
  ttl        INT UNSIGNED NOT NULL default '86400',
  type       ENUM('A','AAAA','ALIAS','CNAME','HINFO','MX','NAPTR','NS','PTR','RP','SRV','TXT'),
  UNIQUE KEY rr (zone,name,type,data)
);

INSERT INTO dns_addresses(zone,name,type,data,ttl) VALUES (1,'','NS','ns01.tpsit.com.', 300);
INSERT INTO dns_addresses(zone,name,type,data,ttl) VALUES (1,'','NS','ns02.tpsit.com.', 300);

--  I want people to be able to use Openstack as http://openstack.tpsit.com so I added this:
INSERT INTO dns_addresses(zone,name,type,data,ttl) VALUES (1,'','A','192.168.42.69', 300);

--
--  The view that MyDNS uses, it combines the dns_addresses table with the host & ip info from Nova
--
--  This union handles 2 different IP ranges, but you can add unions for as many address pools as you would like
--  Offsets are kind of a hack.  I don't think they will even matter since all the queries will be by host name
--
CREATE OR REPLACE VIEW dns_addresses_view AS
  SELECT id,zone,name,data,aux,ttl,type FROM dns_addresses UNION
  SELECT instances.id+42000 AS id,1 AS zone, hostname AS name, address AS data, 0 AS aux, 300 AS ttl, 'A' AS type
    FROM instances,fixed_ips WHERE instances.id = fixed_ips.instance_id UNION
  SELECT instances.id+69000 AS id,2 AS zone, hostname AS name, floating_ips.address AS data, 0 AS aux, 300 AS ttl, 'A' AS type
    FROM instances,floating_ips,fixed_ips WHERE floating_ips.fixed_ip_id = fixed_ips.id AND instances.id = fixed_ips.instance_id;

